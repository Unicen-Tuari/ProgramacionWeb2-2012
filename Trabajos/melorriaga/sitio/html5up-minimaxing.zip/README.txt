Minimaxing 2.0 by HTML5 Up!
html5up.net | @nodethirtythree
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

This is Minimaxing, a fully responsive HTML5 site template designed by nodethirtythree
and released for free by HTML5 Up! It features a simple, lightweight design, solid HTML5
and CSS3 code, and full responsive support for desktop, tablet, and mobile displays.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

- AJ (@nodethirtythree)

PS: This site template is fully responsive, meaning it'll look great on desktop 
(widescreen and standard), tablet and mobile device displays. To see what this looks
like, just narrow down your browser window and hit "reload".